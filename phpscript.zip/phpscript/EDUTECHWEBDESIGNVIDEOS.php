<?p
<html>
<head> <h1>EDUTECH TRAINING CONSULTS</h1> </head>
<body id="bodyVID"onload="changeBgImg()">
<section id="section">
<div id="div1">
<menu id="men" type="context"> 
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGN.php'"><menuitem class="mn"label="home">HOME</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNMISSION.php'"><menuitem class="mn"label="home">MISSION</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNVISION.php'"><menuitem class="mn"label="home">VISION</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNPRODUCTS.php'"><menuitem class="mn"label="home">PRODUCTS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNSERVICES.php'"><menuitem class="mn"label="home">SERVICES</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNREGISTRATIONS.php'"><menuitem class="mn"label="home">REGISTRATIONS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNPARTNERS.php'"><menuitem class="mn"label="home">PARTNERS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNPROJECTS.php'"><menuitem class="mn"label="home">PROJECTS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNTRAINING.php'"><menuitem class="mn"label="home" >TRAININGS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNADVERTS.php'"><menuitem class="mn"label="home">ADVERTS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNVIDEOS.php'"><menuitem class="mn"label="home">VIDEOS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNCONTRACTS.php'"><menuitem class="mn"label="home">CONTRACTS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNCONTACTS.php'"><menuitem class="mn"label="home">CONTACTS</menuitem></button>
</menu>
</div>
<div class="div2">
<h2 > WELCOME TO EDUTECH TRAINING CONSULTS</h2>
<p > We offer training in education and technology through our partnership with technological industries.<br>
We also provide schools with current educational and technological products which can move the school to the next level.<br>
We are passionate about delivering top services with optimal returns.<br>
We serves as a bridge between the school and the technological industries.
</p>
</div>

</section>
<link rel="stylesheet" type="text/css" href="mystyle.css">
<script src="myJscript.js"></script>

</body>
 </html>
 ?>