/* function changeBgImg(){
	setInterval(myBgImg1,2000)
	setInterval(myBgImg2,3000)
	setInterval(myBgImg3,4000)
	setInterval(myBgImg4,5000)
	setInterval(myBgImg5,6000)
	setInterval(myBgImg6,7000)
	setInterval(myBgImg7,8000)
	setInterval(myBgImg8,9000)
	setInterval(myBgImg9,10000)
	setInterval(myBgImg10,11000)
	setInterval(myBgImg11,12000)
	setInterval(myBgImg12,13000)
	setInterval(myBgImg13,14000)
    setInterval(myBgImg14,15000) 	
}

function myBgImg1(){
document.body.style.backgroundImage="url('img100.jpg')";	
}
function myBgImg2(){
document.body.style.backgroundImage="url('img101.png')";	
}
function myBgImg3(){
document.body.style.backgroundImage="url('img102.jpg')";	
}
function myBgImg4(){
document.body.style.backgroundImage="url('img103.png')";	
}
function myBgImg5(){
document.body.style.backgroundImage="url('img104.jpg')";	
}
function myBgImg6(){
document.body.style.backgroundImage="url('img105.jpg')";	
}
function myBgImg7(){
document.body.style.backgroundImage="url('img1.jpg')";	
}
function myBgImg8(){
document.body.style.backgroundImage="url('img2.jpg')";	
}
function myBgImg9(){
document.body.style.backgroundImage="url('img3.jpg')";	
}
function myBgImg10(){
document.body.style.backgroundImage="url('img7.jpg')";	
}
function myBgImg11(){
document.body.style.backgroundImage="url('img8.jpg')";	
}
function myBgImg12(){
document.body.style.backgroundImage="url('img10.jpg')";	
}
function myBgImg13(){
document.body.style.backgroundImage="url('img11.jpg')";	
}
function myBgImg14(){
document.body.style.backgroundImage="url('img12.jpg')";	
}
 */