function FizzBuzz(num){
	if(num%3==0&&num%5==0){
		window.alert("FizzBuzz");
	}
	else if(num%3==0){
		window.alert("Fizz");
	}
	else if(num%5==0){
		window.alert("Buzz");
	}
	else{
		window.alert(num);
	}
	
     }
