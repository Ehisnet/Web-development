<?p
<html>
<head> <h1>EDUTECH TRAINING CONSULTS</h1> </head>
<body id="bodyTR"onload="changeBgImg()">
<section id="section">
<div id="div1" style="overflow-x:auto;">
<menu id="men" type="context"> 
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGN.php'"><menuitem class="mn"label="home">HOME</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNMISSION.php'"><menuitem class="mn"label="home">MISSION</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNVISION.php'"><menuitem class="mn"label="home">VISION</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNPRODUCTS.php'"><menuitem class="mn"label="home">PRODUCTS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNSERVICES.php'"><menuitem class="mn"label="home">SERVICES</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNREGISTRATIONS.php'"><menuitem class="mn"label="home">REGISTRATIONS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNPARTNERS.php'"><menuitem class="mn"label="home">PARTNERS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNPROJECTS.php'"><menuitem class="mn"label="home">PROJECTS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNTRAINING.php'"><menuitem class="mn"label="home" >TRAININGS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNADVERTS.php'"><menuitem class="mn"label="home">ADVERTS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNVIDEOS.php'"><menuitem class="mn"label="home">VIDEOS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNCONTRACTS.php'"><menuitem class="mn"label="home">CONTRACTS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNCONTACTS.php'"><menuitem class="mn"label="home">CONTACTS</menuitem></button>
</menu>
</div>
<!-----<div id="trhead">----->
<h2 id="h2"> <span>EDUTECH CONSULTING COMPANY BRIDGING THE GAP BETWEEN EDUCATION AND INNOVATION.</span></h2><br>
</div>
<h3 id="h3">SMART PROJECT TRAINING SCHEDULE</h3>
<div style="overflow-x:auto;"> 
<table class="table">
<tr>
<th class="table">DAY1</th>
<th class="table">TRAINING</th>
</tr>
<tr>
<td class="table">10.00am to 11.00am </td>
<td>
<ul>
<li class="table">Introduction to Automation.</li>
<li class="table">Problem Solving Methodology using System thinking, collaboration and Learning While Doing methodology.</li>
 </ul>
 </td>
<tr>
<td class="table">11.00am to 11.30pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table">11.30am to 1.30pm </td>
<td>
<ul>
<li class="table">Introduction to Arduino Smart device and Electronics.</li>
<li class="table">Introduction to C programming.</li>
 </ul>
 </td>
 </tr>
 <tr>
 <td class="table">1.30pm to 2.00pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table">2.00pm to 4.00pm </td>
<td>
<ul>
<li class="table">Collaboration of Schools.</li>
<li class="table"> Brainstorming.<li>
<li class="table">Assignments.</li>
 </ul>
 </td>
</tr>
<tr>
<th class="table">DAY2</th>
<th class="table">TRAINING</th>
</tr>
<tr>
<td class="table">10.00am to 11.40am </td>
<td>
<ul>
<li class="table">Lab one: Simple Electric Circuit Design.</li>
<li class="table">Lab two: Series and Parallel Circuit Design.</li>
<li class="table">Smart Electric Circuit Design.</li>
</ul>
 </td>
<tr>
<td class="table">11.40am to 12.10pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table">12.10pm to 1.50pm </td>
<td>
<ul>
<li class="table">Lab three: Automatic Lighting System Design.</li>
<li class="table"> Lab Four: Automatic Temperature Control System Design.</li>
 </ul>
 </td>
 </tr>
 <tr>
 <td class="table">1.50pm to 2.20pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table">2.20pm to 4.00pm </td>
<td>
<ul>
<li class="table">Lab Five: Automatic Alarm System Design.</li> 
<li class="table">Lab Six: Liquid Crystal Display.</li>
 </ul>
 </td>
</tr>
<tr>
<th class="table">DAY3</th>
<th class="table">TRAINING</th>
</tr>
<tr>
<td class="table">10.00am to 12.00pm </td>
<td>
<ul>
<li class="table">Printed Circuit Board Design.</li>
<li class="table">Power Point / Scratch presentation tutorial.</li>
</ul>
 </td>
<tr>
<td class="table">12.00pm to 12.30pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table">12.30pm to 2.30pm </td>
<td>
<ul>
<li class="table">Project Development.</li>
<li class="table">Logic Flow charts Analysis.</li>
 </ul>
 </td>
 </tr>
 <tr>
 <td class="table">2.30pm to 3.00pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table">3.00pm to 4.00pm </td>
<td>
<ul>
<li class="table">Costing and Bill of Materials.</li>
<li class="table">Testing and Implementation.</li>
 </ul>
 </td>
</tr>
<tr>
<th class="table">DAY4</th>
<th class="table">TRAINING</th>
</tr>
<tr>
<td class="table">10.00am to 12.00pm </td>
<td>
<ul>
<li class="table">Printed Circuit Board Development.
<li class="table">Power Point Presentation and Scratch Animation Development.</li>
 </ul>
 </td>
<tr>
<td class="table">12.00pm to 12.30pm </td>
<td class="table"> BREAK</td>
</tr>
<tr>
 <td class="table"  >12.30pm to 2.30pm </td>
<td>
<ul>
<li  class="table">Project Presentation.</li>
<li  class="table">Project Presentation.</li>
 </ul>
 </td>
 </tr>
 <tr>
 <td  class="table">2.30pm to 3.00pm </td>
<td  class="table"> BREAK</td>
</tr>
<tr>
 <td  class="table">3.00pm to 4.00pm </td>
<td>
<ul>
<li  class="table">Project Presentation.</li>
<li  class="table">Project Presentation.</li>
<li  class="table">Selection of 3 innovative Projects.</li>
</li>
 </ul>
 </td>
</tr>
</table>
</div> 

</section>
<link rel="stylesheet" type="text/css" href="mystyle.css">
<script src="myJscript.js"></script>

</body>
 </html>
 ?>