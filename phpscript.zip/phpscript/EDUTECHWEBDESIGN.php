<?p
<html>
<head> <h1 id="head">EDUTECH TRAINING CONSULTS</h1></head>
<body id="bodyHM"onload="changeBgImg()">
<div id="div1">
<menu id="men" type="context"> 
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGN.php'"><menuitem class="mn"label="home">HOME</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNMISSION.php'"><menuitem class="mn"label="home">MISSION</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNVISION.php'"><menuitem class="mn"label="home">VISION</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNPRODUCTS.php'"><menuitem class="mn"label="home">PRODUCTS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNSERVICES.php'"><menuitem class="mn"label="home">SERVICES</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNREGISTRATIONS.php'"><menuitem class="mn"label="home">REGISTRATIONS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNPARTNERS.php'"><menuitem class="mn"label="home">PARTNERS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNPROJECTS.php'"><menuitem class="mn"label="home">PROJECTS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNTRAINING.php'"><menuitem class="mn"label="home" >TRAININGS</menuitem></button>
<button class="btn" onclick="window.location.href='EDUTECHWEBDESIGNADVERTS.php'"><menuitem class="mn"label="home">ADVERTS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNVIDEOS.php'"><menuitem class="mn"label="home">VIDEOS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNCONTRACTS.php'"><menuitem class="mn"label="home">CONTRACTS</menuitem></button>
<button class="btn"onclick="window.location.href='EDUTECHWEBDESIGNCONTACTS.php'"><menuitem class="mn"label="home">CONTACTS</menuitem></button>
</menu>
<section class="section1">
<h1>
PROPOSAL FOR TRAINING OF SCHOOLS ON THE USE OF ARDUINO FOR AUTOMATIVE PROJECTS
</h1>
<div class="first">
<p>
I ovienloba Abraham Ehiabhi hereby use this opportunity or medium to invite your school to be a partof<br>
 the ARDUINO TRAINING PROGRAMME which is geared towards developing young minds in the use of<br>
 arduino and other microcontrollers in solving both global and local problems in our society.<br>
</p>
</div>
<div class="second">
<p>
I am currently a teacher and trainer who has the passion for developing young minds in the secondary<br>
 schools in achieving excellence in their chosen professions. I started my training of students in Ogbomoso<br>
 in Oyo state where I served in 2013. I coordinated the projects initiated by a Jss2 student on the use of<br>
 solar powered lawn mower for clearing of the school environments which was always bushy.
</p>
</div>
<div class="third">
<p>
The projects was said to be very innovative and also came second during the first annual SEED events<br>
 which took place in Lagos. Have been involved in the training of schools all over the federations since<br>
then through partnership with the <em>Schlumberger Excellence in Educational Development (SEED)</em> as an<br>
 Arduino Facilitator. 
</p>
</div>
<div class="fourth">
<h3>
The followings are the Methodologies/Packages involved in the training:
</h3>
<p>
<ol>
<li>
Problem Solving Methodology using System thinking.
</li>
<li>
Collaborative training Methodology (Networking of Ideas and team work ).
</li>
<li>
Project Presentation Methodology (using Scratch Animation Software and PowerPoint).
</li>
<li>
Learning While Doing (LWD) Methodology. (constructionism).
</li>
<li>
Arduino Software/hardware  training.
</li>
<li>
Printed Circuit Board(PCB) Design.
</li>
</ol>
</p>
</section>
<section>
<nav class="nav">
<h2> 
WELCOME TO EDUTECH TRAINING CONSULTS
</h2>
<p> 
We offer training in education and technology through our partnership with technological industries.<br>
We also provide schools with current educational and technological products which can move the school to the next level.<br>
We are passionate about delivering top services with optimal returns.<br>
We serves as a bridge between the school and the technological industries.
</p>
</nav>
</section>

<link rel="stylesheet" type="text/css" href="mystyle.css">
<script src="myJscript.js"></script>

</body>
 </html>
 ?>